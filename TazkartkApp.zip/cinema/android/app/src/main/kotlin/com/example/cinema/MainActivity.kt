package com.example.cinema

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
